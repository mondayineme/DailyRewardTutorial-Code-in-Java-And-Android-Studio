package com.inemesmart.dailyrewardtutorial;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Calendar calender = Calendar.getInstance();
        int year = calender.get(Calendar.YEAR);
        int month = calender.get(Calendar.MONTH);
        int day = calender.get(Calendar.DAY_OF_MONTH);

        String today = year + "" + month + "" + day;

        SharedPreferences preferences = getPreferences(MODE_PRIVATE);
        boolean currentDay = preferences.getBoolean(today, false);

        if (!currentDay){
            //Do your stuff this day
            Toast.makeText(this, "User Rewarded Successfully..", Toast.LENGTH_SHORT).show();
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean(today, true);
            editor.apply();
        }
    }
}